clear;clc;close all;
cond=2; %1)vis-vis 2)ves-ves 
avgLast3 = 0; % 1 - "previous trial" is the average of 3 last trials
% 0 - "previous trial" is 1 last trial
%avgChoices = 0; % 1 - prevC is the average of 3 choices, 0 - mode
%---------------------------------------------------------------------
% % calculate RMS for normalizing HD - load data from all conditions
bigTable = table();
allHD=[];
for condInd=1:2
    switch condInd
        case 1 %vis-vis
            load('/Users/shirhabusha/Downloads/lab/analyses/feedBack/vis-vis/All/Results.mat');
        case 2 %ves-ves
            load('/Users/shirhabusha/Downloads/lab/analyses/feedBack/ves-ves/All/Results.mat');
        otherwise
            warning('Calculate RMS - condition directory does not exist');
    end
    for i=1:length(dataRec)
        if ~isempty(dataRec{i})
            allHD=[allHD dataRec{i}.dir];
        end
    end
end
% calc RMS
rmsHD=rms(allHD)% ///IMPORTANT: I did it like this because we don't need rms right now,
%when we need it again delete the next row and and make this row active
%rmsHD=1; %Adam want me to use Shir's rms so I took it from her simulation
%rmsHD=5.8396;  % taken from model - to unnormalize the betas here
%----------------------------------------------------------------------------------------------------
condLabel={'vis-vis' 'ves-ves' 'ves-vis' 'vis-ves'};
DATA_DIR = '/Users/shirhabusha/Downloads/lab/analyses/feedBack';
DATA_DIR=strcat(DATA_DIR,'/',condLabel{cond});
ALL_DIR = strcat(DATA_DIR,'/All');

MODEL_DIR = strcat(DATA_DIR,'/Prev stim model both');
load(strcat(ALL_DIR,'/Results'));

switch cond
    case 1 %vis-vis
        stimuli=[2]; % 1-vestibular, 2-visual, 3-combined
    case 2 %ves-ves
        stimuli=[1]; % 1-vestibular, 2-visual, 3-combined
    otherwise
        warning('CONDITION NUMBER NOT DEFINED');
end
stimuliLabels={'Vestibular' 'Visual' 'Comb'};
coh=[100];
%----------------------------------------------------------
% getting the subjects in the model
display('Subjects in the model:');
m=0; % counter for subjects in the model
for sub=1:length(subj_NUM)
    currSum=sum(sess_subjNUM==subj_NUM(sub)&~sess_exclude);
    if currSum>0 % the subjects had some sessions
        disp(subj_NUM(sub));
        m=m+1;
        model_subjNUM(m)=subj_NUM(sub);
        model_subjSEX(m)=subj_SEX(sub);
    end
end

repeatingCoh=[0 0 0]; % if there are some sessions of the same coh indicate them all here.
% For example, in Adam's ASD data they sometimes had 3 sessions of 0% coh so it should be: [0 0 0]
group={'ASD' ''};
%---------------------------------------------------------------------

%% *** Previous choice model ***

% getting the paramteres for each subject in the model, on each coherence, on each stimulus type
for s=1:length(stimuli)
    for c=1:length(coh)
        for m=1:length(model_subjNUM)
            subInd=find(sess_subjNUM==model_subjNUM(m)&sess_coherence==coh(c)&~sess_exclude);
            if ~isempty(subInd)% &~(model_subjNUM(m)==384538&coh(c)==50&stimuli(s)==2) %particular subject in adam's ASD data that in the 50% coh had no visual cond.
                for currSubInd=1:length(subInd) % when there are repeating coherences sessions, subInd is >1
                    % find all trials index in this stimulus and coherence
                    trialsInd=find(dataRec{subInd(currSubInd)}.stimType==stimuli(s) | dataRec{subInd(currSubInd)}.stimType==stimuli(s)+3);
                 
                    % Using all responses as data points, we need these vectors:
                    dirVec=dataRec{subInd(currSubInd)}.dir; % vector of HD
                    dirVecNormRMS=dirVec./rmsHD; % normalize HD vector
                    respVec=dataRec{subInd(currSubInd)}.response; % vector of participant's responses
                    stimVec=dataRec{subInd(currSubInd)}.stimType; % vector of stimulus types
                    corVec=dataRec{subInd(currSubInd)}.cor; % vector of stimulus types
                    incorVec=dataRec{subInd(currSubInd)}.incor; % vector of stimulus types
                    
                    if ~isempty(trialsInd)
                        % start at least at trial 2 so we can have a prior trial
                        trialsInd=trialsInd(find(trialsInd>=2));
                        
                        respVec((respVec~=1)&(respVec~=2))=NaN;
                        respVec01=respVec;
                        respVec01(respVec01==1)=-1; % left will be -1
                        respVec01(respVec01==2)=1; % right will be 1
                        
                        data_for_modelling.subjNum = [];
                        data_for_modelling.subjSex = [];                        
                        data_for_modelling.stimType = [];
                        data_for_modelling.trialNum = [];
                        data_for_modelling.currChoice = [];
                        data_for_modelling.currStim = [];
                        data_for_modelling.prevCorChoice = [];
                        data_for_modelling.prevIncorChoice = [];
                        data_for_modelling.prevStim = [];
                        
                        % prepare vectors for regression and for save
                        for t=1:length(trialsInd)
                            data_for_modelling.subjNum = [data_for_modelling.subjNum model_subjNUM(m)-600];
                            data_for_modelling.subjSex = [data_for_modelling.subjSex model_subjSEX(m)];                            
                            data_for_modelling.stimType = [data_for_modelling.stimType stimVec(trialsInd(t))];
                            data_for_modelling.trialNum = [data_for_modelling.trialNum trialsInd(t)];
                            data_for_modelling.currChoice = [data_for_modelling.currChoice respVec01(trialsInd(t))];
                            
                            if corVec(trialsInd(t)) == 1
                                data_for_modelling.prevCorChoice = [data_for_modelling.prevCorChoice respVec01(trialsInd(t)-1)];
                            else
                                data_for_modelling.prevCorChoice = [data_for_modelling.prevCorChoice 0];
                            end
                            if incorVec(trialsInd(t)) == 1
                                data_for_modelling.prevIncorChoice = [data_for_modelling.prevIncorChoice respVec01(trialsInd(t)-1)];
                            else
                                data_for_modelling.prevIncorChoice = [data_for_modelling.prevIncorChoice 0];
                            end
                            data_for_modelling.currStim = [data_for_modelling.currStim dirVecNormRMS(trialsInd(t))];
                            data_for_modelling.prevStim = [data_for_modelling.prevStim dirVecNormRMS(trialsInd(t)-1)];
                        end
                        data_for_modelling.currChoice(data_for_modelling.currChoice==-1)=0; %dependent variable is 0/1
                    end

            % Constructing the design matrix X and response vector y
            X = [data_for_modelling.currStim', data_for_modelling.prevCorChoice', ...
                 data_for_modelling.prevIncorChoice', data_for_modelling.prevStim'];
            y = data_for_modelling.currChoice';

            tbl = table(data_for_modelling.subjNum',data_for_modelling.subjSex', y, X(:,1), X(:,2), X(:,3), X(:,4), ...
                'VariableNames', {'SubjNum', 'SubjSex', 'Response', 'CurrStim', ...
                  'PrevCorChoice', 'PrevIncorChoice', 'PrevStim'});
            bigTable=vertcat(bigTable, tbl);
            
                end
            end
        end
    end
end

bigTableIncor = bigTable;

rowsToDelete = (bigTableIncor.PrevIncorChoice == 0);
bigTableIncor(rowsToDelete, :) = [];
bigTableIncor = removevars(bigTableIncor, 'PrevCorChoice');
feedbackType = repmat("Incor", size(bigTableIncor, 1), 1);
bigTableIncor.FeedbackType = feedbackType;
bigTableIncor = renamevars(bigTableIncor, 'PrevIncorChoice', 'PrevChoice');

% Save the modified table to a CSV file
if cond == 2 %ves
    writetable(bigTableIncor, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTableIncor.csv');
elseif cond ==1 %vis
    writetable(bigTableIncor, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTableIncor.csv');
end 
bigTableCor = bigTable;

rowsToDelete = (bigTableCor.PrevCorChoice == 0);
bigTableCor(rowsToDelete, :) = [];
bigTableCor = removevars(bigTableCor, 'PrevIncorChoice');
feedbackType = repmat("Cor", size(bigTableCor, 1), 1);
bigTableCor.FeedbackType = feedbackType;
bigTableCor = renamevars(bigTableCor, 'PrevCorChoice', 'PrevChoice');

if cond == 2 %ves
    % Save the modified table to a CSV file
    writetable(bigTableCor, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTableCor.csv');
    
    % Read the three CSV files into separate tables
    table1 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTablenofeedback.csv');
    table2 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTableIncor.csv');
    table3 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTableCor.csv');
    
    % Vertically concatenate the tables
    concatenatedTable = vertcat(table1, table2, table3);
    
    % Save the concatenated table to a new CSV file
    writetable(concatenatedTable, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/ves/bigTableAll.csv');

elseif cond ==1 %vis
    % Save the modified table to a CSV file
    writetable(bigTableCor, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTableCor.csv');
    
    % Read the three CSV files into separate tables
    table1 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTablenofeedback.csv');
    table2 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTableIncor.csv');
    table3 = readtable('/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTableCor.csv');
    
    % Vertically concatenate the tables
    concatenatedTable = vertcat(table1, table2, table3);
    
    % Save the concatenated table to a new CSV file
    writetable(concatenatedTable, '/Users/shirhabusha/Downloads/lab/analyses/bigTable/vis/bigTableAll.csv');
end


clear;clc;close all;

cond=2;
condLabel={'ves-ves' 'vis-vis'};

DATA_DIR = strcat('C:\Users\USER\Documents\lab\analyses\feedBack\',condLabel{cond});

ALL_DIR = strcat(DATA_DIR,'\All');
SUB_DIR = strcat(DATA_DIR,'\Subjects');

global is_new_pfit %shir - for using the new pfit
is_new_pfit = 1;

HO = 1; %heading offset (m=1 is the headings for INstring. INnum, however, starts at 1)

%read in subject information
[INnum, INstring] = xlsread(strcat(DATA_DIR,'\All input_',condLabel{cond},'.xlsx'),'subjects');
[~,IX] = sort(INnum(:,1)); %in order of ascending subj_NUM
subj_NUM  = INnum(IX,1);
subj_AGE = INnum(IX,2);
subj_SEX = INstring(IX+HO,3);
subj_EXCL = INstring(IX+HO,4);
subj_COMM = INstring(IX+HO,5);

% Read in session information
[INnum, INstring] = xlsread(strcat(DATA_DIR,'\\All input_',condLabel{cond},'.xlsx'),'sessions');
sess_n = size(INnum,1);
i=0;
% Get session info
for sess_i=1:sess_n
    i = i+1;
    disp(sprintf('Processing session %u',sess_i));
    filename = INstring{sess_i+HO,4};
    
    % Reading data file
    disp(sprintf('Reading file - %s',filename));
    filename_full_in=sprintf('%s\\Raw merged\\%s.mat',DATA_DIR,filename);
    filename_full_out=sprintf('%s\\Subjects\\%s.mat',DATA_DIR,filename);
    filename_full_out_corr=sprintf('%s\\Subjects\\%s_corr.mat',DATA_DIR,filename);
    filename_full_out_incorr=sprintf('%s\\Subjects\\%s_incorr.mat',DATA_DIR,filename);
    data = importdata(filename_full_in);
    if isfield(data, 'SavedInfo') %sometimes the data is saved in a field called "SavedInfo" - I don't know why it sometimes is\not?
        data=data.SavedInfo;
    end
    
    % Prepare prior Resp
    data.PriorResp = data.Resp;
    data.PriorResp.responseTime = data.Resp.responseTime(1:end-1);
    data.PriorResp.confidenceResponseTime = data.Resp.confidenceResponseTime(1:end-1);
    data.PriorResp.response = data.Resp.response(1:end-1);
    data.PriorResp.confidence = data.Resp.confidence(1:end-1);
    data.PriorResp.dir = data.Resp.dir(1:end-1);
    data.PriorResp.corr = data.Resp.corr(1:end-1);
    data.PriorResp.incorr = data.Resp.incorr(1:end-1);
    data.PriorResp.null = data.Resp.null(1:end-1);
    data.PriorResp.dontKnow = data.Resp.dontKnow(1:end-1);
    data.PriorResp.trialCount = data.Resp.trialCount(1:end-1);
    
    data.PriorResp.headYaw = data.Resp.headYaw(1:end-1,1:end);
    data.PriorResp.headRoll = data.Resp.headRoll(1:end-1,1:end);
    data.PriorResp.headPitch = data.Resp.headPitch(1:end-1,1:end);
    
    % Prepare shortened Resp
    data.Resp.responseTime = data.Resp.responseTime(2:end);
    data.Resp.confidenceResponseTime = data.Resp.confidenceResponseTime(2:end);
    data.Resp.response = data.Resp.response(2:end);
    data.Resp.confidence = data.Resp.confidence(2:end);
    data.Resp.dir = data.Resp.dir(2:end);
    data.Resp.corr = data.Resp.corr(2:end);
    data.Resp.incorr = data.Resp.incorr(2:end);
    data.Resp.null = data.Resp.null(2:end);
    data.Resp.dontKnow = data.Resp.dontKnow(2:end);
    data.Resp.trialCount = data.Resp.trialCount(2:end);
    
    data.Resp.headYaw = data.Resp.headYaw(2:end,1:end);
    data.Resp.headRoll = data.Resp.headRoll(2:end,1:end);
    data.Resp.headPitch = data.Resp.headPitch(2:end,1:end);
    
    % Prepare prior Rep
    data.PriorRep.Trial = data.Rep.Trial(1:end-1);
    data.Rep.Trial = data.Rep.Trial(2:end);
    
    
    for jj=1:length(data.Rep.Trial)
        iStim = strmatch('STIMULUS_TYPE',{char(data.Rep.Trial(1).Param.name)},'exact');
        if data.Rep.Trial(jj).Param(iStim).name == 'STIMULUS_TYPE'
            prev_stim_type = data.Rep.Trial(jj).Param(iStim).value;
            data.Rep.Trial(jj).Param(iStim).value = prev_stim_type;
        
        else
            disp("stimulus type not in 53")
        end
    end
    
    is_corr = data.PriorResp.corr == 1 & data.PriorResp.null ~= 1;
    is_corr_sv = data.PriorResp.corr == 1 & data.PriorResp.null ~= 1;
    data_save = data;
    
    data.PriorResp.responseTime = data.PriorResp.responseTime(is_corr);
    data.PriorResp.confidenceResponseTime = data.PriorResp.confidenceResponseTime(is_corr);
    data.PriorResp.response = data.PriorResp.response(is_corr);
    data.PriorResp.confidence = data.PriorResp.confidence(is_corr);
    data.PriorResp.dir = data.PriorResp.dir(is_corr);
    data.PriorResp.corr = data.PriorResp.corr(is_corr);
    data.PriorResp.incorr = data.PriorResp.incorr(is_corr);
    data.PriorResp.null = data.PriorResp.null(is_corr);
    data.PriorResp.dontKnow = data.PriorResp.dontKnow(is_corr);
    data.PriorResp.trialCount =  data.PriorResp.trialCount(is_corr);
    
    data.PriorResp.headYaw = data.PriorResp.headYaw(is_corr,1:end);
    data.PriorResp.headRoll = data.PriorResp.headRoll(is_corr,1:end);
    data.PriorResp.headPitch = data.PriorResp.headPitch(is_corr,1:end);
    
    % Prepare shortened Resp
    data.Resp.responseTime = data.Resp.responseTime(is_corr);
    data.Resp.confidenceResponseTime = data.Resp.confidenceResponseTime(is_corr);
    data.Resp.response = data.Resp.response(is_corr);
    data.Resp.confidence = data.Resp.confidence(is_corr);
    data.Resp.dir = data.Resp.dir(is_corr);
    data.Resp.corr = data.Resp.corr(is_corr);
    data.Resp.incorr = data.Resp.incorr(is_corr);
    data.Resp.null = data.Resp.null(is_corr);
    data.Resp.dontKnow = data.Resp.dontKnow(is_corr);
    data.Resp.trialCount =data.Resp.trialCount(is_corr);
    
    data.Resp.headYaw = data.Resp.headYaw(is_corr,1:end);
    data.Resp.headRoll = data.Resp.headRoll(is_corr,1:end);
    data.Resp.headPitch = data.Resp.headPitch(is_corr,1:end);
    
    % Prepare prior Rep
    data.PriorRep.Trial = data.PriorRep.Trial(is_corr);
    data.Rep.Trial = data.Rep.Trial(is_corr);
    
    
    data_corr = data;
    data = data_save;
    is_corr = data.PriorResp.corr == 0 & data.PriorResp.null ~= 1;
    is_incorr_sv = data.PriorResp.corr == 0 & data.PriorResp.null ~= 1;
    
    
    data.PriorResp.responseTime = data.PriorResp.responseTime(is_corr);
    data.PriorResp.confidenceResponseTime = data.PriorResp.confidenceResponseTime(is_corr);
    data.PriorResp.response = data.PriorResp.response(is_corr);
    data.PriorResp.confidence = data.PriorResp.confidence(is_corr);
    data.PriorResp.dir = data.PriorResp.dir(is_corr);
    data.PriorResp.corr = data.PriorResp.corr(is_corr);
    data.PriorResp.incorr = data.PriorResp.incorr(is_corr);
    data.PriorResp.null = data.PriorResp.null(is_corr);
    data.PriorResp.dontKnow = data.PriorResp.dontKnow(is_corr);
    data.PriorResp.trialCount = data.PriorResp.trialCount(is_corr);
    
    data.PriorResp.headYaw = data.PriorResp.headYaw(is_corr,1:end);
    data.PriorResp.headRoll = data.PriorResp.headRoll(is_corr,1:end);
    data.PriorResp.headPitch = data.PriorResp.headPitch(is_corr,1:end);
    
    % Prepare shortened Resp
    data.Resp.responseTime = data.Resp.responseTime(is_corr);
    data.Resp.confidenceResponseTime = data.Resp.confidenceResponseTime(is_corr);
    data.Resp.response = data.Resp.response(is_corr);
    data.Resp.confidence = data.Resp.confidence(is_corr);
    data.Resp.dir = data.Resp.dir(is_corr);
    data.Resp.corr = data.Resp.corr(is_corr);
    data.Resp.incorr = data.Resp.incorr(is_corr);
    data.Resp.null = data.Resp.null(is_corr);
    data.Resp.dontKnow = data.Resp.dontKnow(is_corr);
    data.Resp.trialCount = data.Resp.trialCount(is_corr);
    
    data.Resp.headYaw = data.Resp.headYaw(is_corr,1:end);
    data.Resp.headRoll = data.Resp.headRoll(is_corr,1:end);
    data.Resp.headPitch = data.Resp.headPitch(is_corr,1:end);
    
    % Prepare prior Rep
    data.PriorRep.Trial = data.PriorRep.Trial(is_corr);
    data.Rep.Trial = data.Rep.Trial(is_corr);
    
    data_incorr = data;
    
    data = data_save;
    
    exclude_sess = INstring{sess_i+HO,5};
    exclude_subj = subj_EXCL{subj_NUM==INnum(sess_i,1)};
    exclude = ~isempty(exclude_sess) | ~isempty(exclude_subj);
    
    % general properties
    sess_subjNUM(i) = INnum(sess_i,1);
    sess_AGE(i)=subj_AGE(subj_NUM==sess_subjNUM(i));
    sess_SEX(i)=subj_SEX(subj_NUM==sess_subjNUM(i));
    sess_coherence(i)=100;
    sess_exclude(i) = exclude;
    if (~sess_exclude(i))
        
        % Analyze data and create psychometric curves
        AnaData_corr{i} = analyze_singleYaelAndShir_feedback(filename_full_out_corr,data_corr);
        AnaData_incorr{i} = analyze_singleYaelAndShir_feedback(filename_full_out_incorr,data_incorr);
        
        % Arrange all data in one continuous record - shir 05\2018
        % it will include: trialCount, stimType, dir, response, coherence
        dataRec{i}=oneDataRec_choice_feedback(data_save, is_corr_sv, is_incorr_sv);
        dataRec_cor{i}=oneDataRec_feedback(data_save, is_incorr_sv);
        dataRec_incor{i}=oneDataRec_feedback(data_save, is_corr_sv);
        
        % raw data (that is called merged data) of all subjects together
        All_merged_data{i} = data;
        All_merged_data_cor{i} = data_corr;
        All_merged_data_incor{i} = data_incorr;

    end
end

% Save all data structures
save(strcat(DATA_DIR,'\\All\All_merged_data'),'All_merged_data*');
save(strcat(DATA_DIR,'\\All\All_merged_data_cor'),'All_merged_data_cor*');
save(strcat(DATA_DIR,'\\All\All_merged_data_incor'),'All_merged_data_incor*');
save(strcat(DATA_DIR,'\\All\Results'),'sess_*','subj_*','dataRec*', 'dataRec_cor*', 'dataRec_incor*', 'AnaData_corr*','AnaData_incorr*'); %
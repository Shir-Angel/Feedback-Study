clear;clc;close all;
cond=1; %1)vis-vis 2)ves-ves 
avgLast3 = 0; 

% % calculate RMS for normalizing HD - load data from all conditions
bigTable = table();
allHD=[];
for condInd=1:2
    switch condInd
        case 1 %vis-vis
            load("C:\Users\USER\Documents\lab\analyses\no_feedBack\vis-vis\All\Results.mat");
        case 2 %ves-ves
            load("C:\Users\USER\Documents\lab\analyses\no_feedBack\ves-ves\All\Results.mat")
        otherwise
            warning('Calculate RMS - condition directory does not exist');
    end

    for i=1:length(dataRec)
        if ~isempty(dataRec{i})
            allHD=[allHD dataRec{i}.dir];
        end
    end
end
% calc RMS
rmsHD=rms(allHD); % \\\IMPORTANT: I did it like this because we don't need rms right now,

%----------------------------------------------------------------------------------------------------
condLabel={'vis-vis' 'ves-ves'};
DATA_DIR = 'C:\Users\USER\Documents\lab\analyses\no_feedBack';

DATA_DIR=strcat(DATA_DIR,'\',condLabel{cond});
ALL_DIR = strcat(DATA_DIR,'\All');
MODEL_DIR = strcat(DATA_DIR,'\Prev stim model');
load(strcat(ALL_DIR,'\Results'));

switch cond
    case 1 %vis-vis
        stimuli=[2]; % 1-vestibular, 2-visual, 3-combined
    case 2 %ves-ves
        stimuli=[1]; % 1-vestibular, 2-visual, 3-combined
    otherwise
        warning('CONDITION NUMBER NOT DEFINED');
end
stimuliLabels={'Vestibular' 'Visual' 'Comb'};
coh=[100];
%----------------------------------------------------------
% getting the subjects in the model
display('Subjects in the model:');
m=0; % counter for subjects in the model
for sub=1:length(subj_NUM)
    currSum=sum(sess_subjNUM==subj_NUM(sub)&~sess_exclude);
    if currSum>0 % the subjects had some sessions
        disp(subj_NUM(sub));
        m=m+1;
        model_subjNUM(m)=subj_NUM(sub);
        model_subjSEX(m)=subj_SEX(sub);
    end
end

repeatingCoh=[0 0 0]; % if there are some sessions of the same coh indicate them all here.

group={'ASD' ''};
%---------------------------------------------------------------------

%% *** Previous choice model ***

% getting the paramteres for each subject in the model, on each coherence, on each stimulus type
for s=1:length(stimuli)
    for c=1:length(coh)
        for m=1:length(model_subjNUM)
            subInd=find(sess_subjNUM==model_subjNUM(m)&sess_coherence==coh(c)&~sess_exclude);
            if ~isempty(subInd)% &~(model_subjNUM(m)==384538&coh(c)==50&stimuli(s)==2) %particular subject in adam's ASD data that in the 50% coh had no visual cond.
                for currSubInd=1:length(subInd) % when there are repeating coherences sessions, subInd is >1
                    % find all trials index in this stimulus and coherence
                    trialsInd=find(dataRec{subInd(currSubInd)}.stimType==stimuli(s) | dataRec{subInd(currSubInd)}.stimType==stimuli(s)+3);
                    % Using all responses as data points, we need these vectors:
                    dirVec=dataRec{subInd(currSubInd)}.dir; % vector of HD
                    dirVecNormRMS=dirVec.\rmsHD; % normalize HD vector
                    respVec=dataRec{subInd(currSubInd)}.response; % vector of participant's responses
                    stimVec=dataRec{subInd(currSubInd)}.stimType; % vector of stimulus types
                    
                    if ~isempty(trialsInd);
                        % start at least at trial 2 so we can have a prior trial
                        trialsInd=trialsInd(find(trialsInd>=2));
                        
                        respVec((respVec~=1)&(respVec~=2))=NaN;
                        respVec01=respVec;
                        respVec01(respVec01==1)=-1; % left will be -1
                        respVec01(respVec01==2)=1; % right will be 1
                        
                        data_for_modelling.subjNum = [];
                        data_for_modelling.subjSex = [];
                        data_for_modelling.stimType = [];
                        data_for_modelling.trialNum = [];
                        data_for_modelling.currChoice = [];
                        data_for_modelling.currStim = [];
                        data_for_modelling.prevChoice = [];
                        data_for_modelling.prevStim = [];
                        
                        % prepare vectors for regression and for save
                        for t=1:length(trialsInd)
                            data_for_modelling.subjNum = [data_for_modelling.subjNum model_subjNUM(m)-600];
                            data_for_modelling.subjSex = [data_for_modelling.subjSex model_subjSEX(m)];                            
                            data_for_modelling.stimType = [data_for_modelling.stimType stimVec(trialsInd(t))];
                            data_for_modelling.trialNum = [data_for_modelling.trialNum trialsInd(t)];
                            data_for_modelling.currChoice = [data_for_modelling.currChoice respVec01(trialsInd(t))];
                            data_for_modelling.currStim = [data_for_modelling.currStim dirVecNormRMS(trialsInd(t))];
                            data_for_modelling.prevChoice = [data_for_modelling.prevChoice respVec01(trialsInd(t)-1)];
                            data_for_modelling.prevStim = [data_for_modelling.prevStim dirVecNormRMS(trialsInd(t)-1)];
                        end
                        data_for_modelling.currChoice(data_for_modelling.currChoice==-1)=0; %dependent variable is 0\1
                        end

                        % Constructing the design matrix X and response vector y
                        X = [data_for_modelling.currStim', data_for_modelling.prevChoice', data_for_modelling.prevStim'];
                        y = data_for_modelling.currChoice';
            
                        tbl = table(data_for_modelling.subjNum', data_for_modelling.subjSex', y, X(:,1), X(:,2), X(:,3), ...
                            'VariableNames', {'SubjNum', 'SubjSex', 'Response', 'CurrStim', 'PrevChoice', 'PrevStim'});
                        bigTable=vertcat(bigTable, tbl);
                end
            end
        end
    end
end


% Add a new column "Feedback Type" with all entries set to "No Feedback"
feedbackType = repmat("NoFeedback", size(bigTable, 1), 1);
bigTable.FeedbackType = feedbackType;

rowsToDelete = (isnan(bigTable.PrevChoice));
bigTable(rowsToDelete, :) = [];

if cond == 2
    writetable(bigTable, 'C:\Users\USER\Documents\lab\analyses\bigTable\ves\bigTablenofeedback.csv');   
elseif cond == 1
    writetable(bigTable, 'C:\Users\USER\Documents\lab\analyses\bigTable\vis\bigTablenofeedback.csv');   
end
